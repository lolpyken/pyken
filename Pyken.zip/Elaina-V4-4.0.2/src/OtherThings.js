import { getThemeName } from "../index.js"
export { getThemeName }

window.getThemeName = getThemeName